﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;



namespace GameShips
{
    public partial class Form1 : Form
    {

        List<Button> playerPositionButtons;
        List<Button> enemyPositionButtons;

        Random rand = new Random();
        cEnemy mEnemye;
        cEnemy mEnemyh;
        cMember Gracz;
        cData Dane;
        int PlayerShips = 3;
        int round = 36;
        int playerScore;
        int enemyScore;
        int mScore;
        string difficulty;
         
        public Form1()
        {
            mEnemye = new cEnemyEasy();
            mEnemyh = new cEnemyHard();
            Gracz = new cMember();
            Dane = new cData();

            InitializeComponent();
            RestartGame();      
        }

        private void EnemyPlayTimerEvent(object sender, EventArgs e)
        {
            if (playerPositionButtons.Count > 0 && round > 0)
            {

                int index = rand.Next(playerPositionButtons.Count);

                if ((string)playerPositionButtons[index].Tag == "playerShip")
                {
                    enemyMove.Text = playerPositionButtons[index].Text;
                    playerPositionButtons[index].Enabled = false;
                    playerPositionButtons[index].BackColor = Color.Black;
                    playerPositionButtons.RemoveAt(index);
                    enemyScore += 1;
                    txtEnemy.Text = enemyScore.ToString();
                    EnemyPlayTimer.Stop();
                }
                else
                {
                    enemyMove.Text = playerPositionButtons[index].Text;
                    playerPositionButtons[index].Enabled = false;
                    playerPositionButtons[index].BackColor = Color.Blue;
                    playerPositionButtons.RemoveAt(index);
                    EnemyPlayTimer.Stop();
                }
            }
            if(difficulty == "easy")
            {
                if (round < 1 || enemyScore > 2 || playerScore > 2)
                {
                    if (playerScore > enemyScore)
                    {
                        MessageBox.Show("Wygrales!", "Zwyciestwo");
                        RestartGame();
                    }
                    else if (enemyScore > playerScore)
                    {
                        MessageBox.Show("Przegrales!", "Porazka");
                        RestartGame();
                    }
                    else if (enemyScore == playerScore)
                    {
                        MessageBox.Show("Remis!", "Remis");
                        RestartGame();
                    }
                }
            }
            if(difficulty == "hard")
            {
                if (round < 1 || enemyScore > 2 || playerScore > 5)
                {
                    if (playerScore > enemyScore)
                    {
                        MessageBox.Show("Wygrales!", "Zwyciestwo");
                        RestartGame();
                    }
                    else if (enemyScore > playerScore)
                    {
                        MessageBox.Show("Przegrales!", "Porazka");
                        RestartGame();
                    }
                    else if (enemyScore == playerScore)
                    {
                        MessageBox.Show("Remis!", "Remis");
                        RestartGame();
                    }
                }
            }
           
        }

        private void AttackButtonEvent(object sender, EventArgs e)
        {
            if(EnemyLocationListBox.Text != "")
            {
                var attackPosition = EnemyLocationListBox.Text.ToLower();

                int index = enemyPositionButtons.FindIndex(g => g.Name == attackPosition);

                if(enemyPositionButtons[index].Enabled && round > 0)
                {
                    round -= 1;
                    txtRounds.Text = "Pozostalo tur:" + round;

                    if((string)enemyPositionButtons[index].Tag == "enemyShip")
                    {
                        information.Text = "Ilosc wrogich okretow: " + --mScore;
                        enemyPositionButtons[index].Enabled = false;
                        enemyPositionButtons[index].BackColor = Color.Black;
                        playerScore += 1;
                        txtPlayer.Text = playerScore.ToString();
                        EnemyPlayTimer.Start();
                    }
                    else
                    {
                        enemyPositionButtons[index].Enabled = false;
                        enemyPositionButtons[index].BackColor = Color.Blue;
                        EnemyPlayTimer.Start();
                    }
                }
            }
            else
            {
                MessageBox.Show("Najpierw wybierz pole do ataku", "Blad");
            }
        }

        private void PlayerPositionButtonsEvent(object sender, EventArgs e)
        {
            if(PlayerShips > 0)
            {
                var button = (Button)sender;
                trudny.Enabled = false;
                button.Enabled = false;
                button.Tag = "playerShip";
                button.BackColor = Color.Orange;
                PlayerShips -= 1;
            }

            if(PlayerShips == 0)
            {
                btnAttack.Enabled = true;
                btnAttack.BackColor = Color.Red;
                btnAttack.ForeColor = Color.White;

                txtHelp.Text = "Teraz wybierz jedno z pol i zatwierdz przyciskiem Ognia!";
            }
        }

        private void RestartGame()
        {
            Debug.WriteLine("Nowa Gra");
            difficulty = "easy";
            trudny.Enabled = true;
            playerPositionButtons = new List<Button> { a1, a2, a3, a4, a5, a6, b1, b2, b3, b4, b5, b6, c1, c2, c3, c4, c5, c6, d1, d2, d3, d4, d5, d6, e1, e2, e3, e4, e5, e6, f1, f2, f3, f4, f5, f6 };
            enemyPositionButtons = new List<Button> { g7, g8, g9, g10, g11, g12, h7, h8, h9, h10, h11, h12, i7, i8, i9, i10, i11, i12, j7, j8, j9, j10, j11, j12, k7, k8, k9, k10, k11, k12, l7, l8, l9, l10, l11, l12 };

            EnemyLocationListBox.Items.Clear();

            EnemyLocationListBox.Text = null;

            txtHelp.Text = "Wybierz na swojej mapie trzy inne miejsca na pozycje okretow";

            for(int i=0; i<enemyPositionButtons.Count; i++ )
            {
                enemyPositionButtons[i].Enabled = true;
                enemyPositionButtons[i].Tag = null;
                enemyPositionButtons[i].BackColor = Color.White;
                enemyPositionButtons[i].BackgroundImage = null;
                EnemyLocationListBox.Items.Add(enemyPositionButtons[i].Text);
            }

            for(int i=0; i<playerPositionButtons.Count; i++)
            {
                playerPositionButtons[i].Enabled = true;
                playerPositionButtons[i].Tag = null;
                playerPositionButtons[i].BackColor = Color.White;
                playerPositionButtons[i].BackgroundImage = null;
            }

            playerScore = 0;
            enemyScore = 0;
            round = 36;
            PlayerShips = 3;

            txtPlayer.Text = playerScore.ToString();
            txtEnemy.Text = enemyScore.ToString();
            enemyMove.Text = "A1";
            addsurname.Enabled = true;
            addname.Enabled = true;

            btnAttack.Enabled = false;

            enemyLocationPicker();
            information.Text = "Dostrzeglismy nastepujaca ilosc okretow: " + mScore;
        }

        private void enemyLocationPicker()
        {
            mEnemye.LocationPicker(enemyPositionButtons);
            mScore = mEnemye + mEnemyh;
        }

        private void information_Click(object sender, EventArgs e)
        {

        }

        private void addname_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add("Wyniki podanego gracza:");
            string tName = Add1.Text;
            Gracz.add_Name(tName);
            listBox1.Items.Add("Imie: " + tName);
            addsurname.Enabled = true;
            addname.Enabled = false;

        }

        private void addsurname_Click(object sender, EventArgs e)
        {
            string tSurname = Add1.Text;
            Gracz.add_Surname(tSurname);
            listBox1.Items.Add("Nazwisko: " + tSurname);
            addname.Enabled = false;
            addsurname.Enabled = false;
            Dane.connection();
            
        }

        private void trudny_Click(object sender, EventArgs e)
        {
            difficulty = "hard";
            mEnemye = new cEnemyHard();
            mEnemyh.LocationPicker(enemyPositionButtons);
            mScore += 3;
            information.Text = "Dostrzeglismy nastepujaca ilosc okretow: " + mScore;
            trudny.Enabled = false;
            btnAttack.Enabled = true;
            btnAttack.BackColor = Color.Red;
            btnAttack.ForeColor = Color.White;
        }       
    }
}
