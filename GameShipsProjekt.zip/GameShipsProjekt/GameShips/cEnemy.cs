﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameShips
{
    abstract class cEnemy
    {
        public int licznik = 0;      
        public cEnemy()
        {
            MessageBox.Show("Wybieranie pozycji wroga", "INFO");
        }     
        virtual public void LocationPicker(List<Button> aPositionButtons) { }
        public static int operator +(cEnemy s1, cEnemy s2)
        {
            return s1.licznik + s2.licznik;
        }
        ~cEnemy()
        {
            MessageBox.Show("Koniec", "INFO");
        }
    }
}
