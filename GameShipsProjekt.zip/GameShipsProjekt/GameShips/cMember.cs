﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace GameShips
{
    class cMember
    {
        public string mName;
        public string mSurname;
        public cMember() { }     
        public cMember(string n, string s)
        {
            this.mName = n;
            this.mSurname = s;
        }
        public void add_Name(string tName)
        {
            mName = tName;
        }
        public void add_Surname(string tSurname)
        {
            mSurname = tSurname;
        }
    }
}
