﻿
namespace GameShips
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtPlayer = new System.Windows.Forms.Label();
            this.txtEnemy = new System.Windows.Forms.Label();
            this.txtRounds = new System.Windows.Forms.Label();
            this.enemyMove = new System.Windows.Forms.Label();
            this.txtHelp = new System.Windows.Forms.Label();
            this.EnemyLocationListBox = new System.Windows.Forms.ComboBox();
            this.btnAttack = new System.Windows.Forms.Button();
            this.a1 = new System.Windows.Forms.Button();
            this.a2 = new System.Windows.Forms.Button();
            this.a3 = new System.Windows.Forms.Button();
            this.a4 = new System.Windows.Forms.Button();
            this.a5 = new System.Windows.Forms.Button();
            this.a6 = new System.Windows.Forms.Button();
            this.b6 = new System.Windows.Forms.Button();
            this.b5 = new System.Windows.Forms.Button();
            this.b4 = new System.Windows.Forms.Button();
            this.b3 = new System.Windows.Forms.Button();
            this.b2 = new System.Windows.Forms.Button();
            this.b1 = new System.Windows.Forms.Button();
            this.c6 = new System.Windows.Forms.Button();
            this.c5 = new System.Windows.Forms.Button();
            this.c4 = new System.Windows.Forms.Button();
            this.c3 = new System.Windows.Forms.Button();
            this.c2 = new System.Windows.Forms.Button();
            this.c1 = new System.Windows.Forms.Button();
            this.d6 = new System.Windows.Forms.Button();
            this.d5 = new System.Windows.Forms.Button();
            this.d4 = new System.Windows.Forms.Button();
            this.d3 = new System.Windows.Forms.Button();
            this.d2 = new System.Windows.Forms.Button();
            this.d1 = new System.Windows.Forms.Button();
            this.e6 = new System.Windows.Forms.Button();
            this.e5 = new System.Windows.Forms.Button();
            this.e4 = new System.Windows.Forms.Button();
            this.e3 = new System.Windows.Forms.Button();
            this.e2 = new System.Windows.Forms.Button();
            this.e1 = new System.Windows.Forms.Button();
            this.f6 = new System.Windows.Forms.Button();
            this.f5 = new System.Windows.Forms.Button();
            this.f4 = new System.Windows.Forms.Button();
            this.f3 = new System.Windows.Forms.Button();
            this.f2 = new System.Windows.Forms.Button();
            this.f1 = new System.Windows.Forms.Button();
            this.l12 = new System.Windows.Forms.Button();
            this.l11 = new System.Windows.Forms.Button();
            this.l10 = new System.Windows.Forms.Button();
            this.l9 = new System.Windows.Forms.Button();
            this.l8 = new System.Windows.Forms.Button();
            this.l7 = new System.Windows.Forms.Button();
            this.k12 = new System.Windows.Forms.Button();
            this.k11 = new System.Windows.Forms.Button();
            this.k10 = new System.Windows.Forms.Button();
            this.k9 = new System.Windows.Forms.Button();
            this.k8 = new System.Windows.Forms.Button();
            this.k7 = new System.Windows.Forms.Button();
            this.j12 = new System.Windows.Forms.Button();
            this.j11 = new System.Windows.Forms.Button();
            this.j10 = new System.Windows.Forms.Button();
            this.j9 = new System.Windows.Forms.Button();
            this.j8 = new System.Windows.Forms.Button();
            this.j7 = new System.Windows.Forms.Button();
            this.i12 = new System.Windows.Forms.Button();
            this.i11 = new System.Windows.Forms.Button();
            this.i10 = new System.Windows.Forms.Button();
            this.i9 = new System.Windows.Forms.Button();
            this.i8 = new System.Windows.Forms.Button();
            this.i7 = new System.Windows.Forms.Button();
            this.h12 = new System.Windows.Forms.Button();
            this.h11 = new System.Windows.Forms.Button();
            this.h10 = new System.Windows.Forms.Button();
            this.h9 = new System.Windows.Forms.Button();
            this.h8 = new System.Windows.Forms.Button();
            this.h7 = new System.Windows.Forms.Button();
            this.g12 = new System.Windows.Forms.Button();
            this.g11 = new System.Windows.Forms.Button();
            this.g10 = new System.Windows.Forms.Button();
            this.g9 = new System.Windows.Forms.Button();
            this.g8 = new System.Windows.Forms.Button();
            this.g7 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.EnemyPlayTimer = new System.Windows.Forms.Timer(this.components);
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.information = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.Add1 = new System.Windows.Forms.TextBox();
            this.addname = new System.Windows.Forms.Button();
            this.addsurname = new System.Windows.Forms.Button();
            this.trudny = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtPlayer
            // 
            this.txtPlayer.AutoSize = true;
            this.txtPlayer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtPlayer.Location = new System.Drawing.Point(365, 156);
            this.txtPlayer.Name = "txtPlayer";
            this.txtPlayer.Size = new System.Drawing.Size(53, 37);
            this.txtPlayer.TabIndex = 0;
            this.txtPlayer.Text = "00";
            // 
            // txtEnemy
            // 
            this.txtEnemy.AutoSize = true;
            this.txtEnemy.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtEnemy.Location = new System.Drawing.Point(1243, 156);
            this.txtEnemy.Name = "txtEnemy";
            this.txtEnemy.Size = new System.Drawing.Size(53, 37);
            this.txtEnemy.TabIndex = 1;
            this.txtEnemy.Text = "00";
            // 
            // txtRounds
            // 
            this.txtRounds.AutoSize = true;
            this.txtRounds.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtRounds.Location = new System.Drawing.Point(605, 213);
            this.txtRounds.Name = "txtRounds";
            this.txtRounds.Size = new System.Drawing.Size(259, 37);
            this.txtRounds.TabIndex = 2;
            this.txtRounds.Text = "Pozostalo tur: 36";
            // 
            // enemyMove
            // 
            this.enemyMove.AutoSize = true;
            this.enemyMove.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.enemyMove.Location = new System.Drawing.Point(1198, 41);
            this.enemyMove.Name = "enemyMove";
            this.enemyMove.Size = new System.Drawing.Size(55, 37);
            this.enemyMove.TabIndex = 3;
            this.enemyMove.Text = "A1";
            // 
            // txtHelp
            // 
            this.txtHelp.AutoSize = true;
            this.txtHelp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtHelp.Location = new System.Drawing.Point(36, 749);
            this.txtHelp.Name = "txtHelp";
            this.txtHelp.Size = new System.Drawing.Size(543, 37);
            this.txtHelp.TabIndex = 5;
            this.txtHelp.Text = "Aby zagrac kliknij przycisk rozpocznij";
            // 
            // EnemyLocationListBox
            // 
            this.EnemyLocationListBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EnemyLocationListBox.DropDownWidth = 95;
            this.EnemyLocationListBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.EnemyLocationListBox.FormattingEnabled = true;
            this.EnemyLocationListBox.Location = new System.Drawing.Point(55, 44);
            this.EnemyLocationListBox.Name = "EnemyLocationListBox";
            this.EnemyLocationListBox.Size = new System.Drawing.Size(121, 45);
            this.EnemyLocationListBox.TabIndex = 6;
            // 
            // btnAttack
            // 
            this.btnAttack.Location = new System.Drawing.Point(209, 44);
            this.btnAttack.Name = "btnAttack";
            this.btnAttack.Size = new System.Drawing.Size(111, 63);
            this.btnAttack.TabIndex = 7;
            this.btnAttack.Text = "Ognia!";
            this.btnAttack.UseVisualStyleBackColor = true;
            this.btnAttack.Click += new System.EventHandler(this.AttackButtonEvent);
            // 
            // a1
            // 
            this.a1.Location = new System.Drawing.Point(72, 305);
            this.a1.Name = "a1";
            this.a1.Size = new System.Drawing.Size(84, 63);
            this.a1.TabIndex = 8;
            this.a1.Text = "A1";
            this.a1.UseVisualStyleBackColor = true;
            this.a1.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // a2
            // 
            this.a2.Location = new System.Drawing.Point(162, 305);
            this.a2.Name = "a2";
            this.a2.Size = new System.Drawing.Size(84, 63);
            this.a2.TabIndex = 9;
            this.a2.Text = "A2";
            this.a2.UseVisualStyleBackColor = true;
            this.a2.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // a3
            // 
            this.a3.Location = new System.Drawing.Point(252, 305);
            this.a3.Name = "a3";
            this.a3.Size = new System.Drawing.Size(84, 63);
            this.a3.TabIndex = 10;
            this.a3.Text = "A3";
            this.a3.UseVisualStyleBackColor = true;
            this.a3.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // a4
            // 
            this.a4.Location = new System.Drawing.Point(342, 305);
            this.a4.Name = "a4";
            this.a4.Size = new System.Drawing.Size(84, 63);
            this.a4.TabIndex = 11;
            this.a4.Text = "A4";
            this.a4.UseVisualStyleBackColor = true;
            this.a4.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // a5
            // 
            this.a5.Location = new System.Drawing.Point(432, 305);
            this.a5.Name = "a5";
            this.a5.Size = new System.Drawing.Size(84, 63);
            this.a5.TabIndex = 12;
            this.a5.Text = "A5";
            this.a5.UseVisualStyleBackColor = true;
            this.a5.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // a6
            // 
            this.a6.Location = new System.Drawing.Point(522, 305);
            this.a6.Name = "a6";
            this.a6.Size = new System.Drawing.Size(84, 63);
            this.a6.TabIndex = 13;
            this.a6.Text = "A6";
            this.a6.UseVisualStyleBackColor = true;
            this.a6.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // b6
            // 
            this.b6.Location = new System.Drawing.Point(522, 374);
            this.b6.Name = "b6";
            this.b6.Size = new System.Drawing.Size(84, 63);
            this.b6.TabIndex = 19;
            this.b6.Text = "B6";
            this.b6.UseVisualStyleBackColor = true;
            this.b6.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // b5
            // 
            this.b5.Location = new System.Drawing.Point(432, 374);
            this.b5.Name = "b5";
            this.b5.Size = new System.Drawing.Size(84, 63);
            this.b5.TabIndex = 18;
            this.b5.Text = "B5";
            this.b5.UseVisualStyleBackColor = true;
            this.b5.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // b4
            // 
            this.b4.Location = new System.Drawing.Point(342, 374);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(84, 63);
            this.b4.TabIndex = 17;
            this.b4.Text = "B4";
            this.b4.UseVisualStyleBackColor = true;
            this.b4.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // b3
            // 
            this.b3.Location = new System.Drawing.Point(252, 374);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(84, 63);
            this.b3.TabIndex = 16;
            this.b3.Text = "B3";
            this.b3.UseVisualStyleBackColor = true;
            this.b3.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // b2
            // 
            this.b2.Location = new System.Drawing.Point(162, 374);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(84, 63);
            this.b2.TabIndex = 15;
            this.b2.Text = "B2";
            this.b2.UseVisualStyleBackColor = true;
            this.b2.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // b1
            // 
            this.b1.Location = new System.Drawing.Point(72, 374);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(84, 63);
            this.b1.TabIndex = 14;
            this.b1.Text = "B1";
            this.b1.UseVisualStyleBackColor = true;
            this.b1.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // c6
            // 
            this.c6.Location = new System.Drawing.Point(522, 443);
            this.c6.Name = "c6";
            this.c6.Size = new System.Drawing.Size(84, 63);
            this.c6.TabIndex = 25;
            this.c6.Text = "C6";
            this.c6.UseVisualStyleBackColor = true;
            this.c6.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // c5
            // 
            this.c5.Location = new System.Drawing.Point(432, 443);
            this.c5.Name = "c5";
            this.c5.Size = new System.Drawing.Size(84, 63);
            this.c5.TabIndex = 24;
            this.c5.Text = "C5";
            this.c5.UseVisualStyleBackColor = true;
            this.c5.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // c4
            // 
            this.c4.Location = new System.Drawing.Point(342, 443);
            this.c4.Name = "c4";
            this.c4.Size = new System.Drawing.Size(84, 63);
            this.c4.TabIndex = 23;
            this.c4.Text = "C4";
            this.c4.UseVisualStyleBackColor = true;
            this.c4.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // c3
            // 
            this.c3.Location = new System.Drawing.Point(252, 443);
            this.c3.Name = "c3";
            this.c3.Size = new System.Drawing.Size(84, 63);
            this.c3.TabIndex = 22;
            this.c3.Text = "C3";
            this.c3.UseVisualStyleBackColor = true;
            this.c3.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // c2
            // 
            this.c2.Location = new System.Drawing.Point(162, 443);
            this.c2.Name = "c2";
            this.c2.Size = new System.Drawing.Size(84, 63);
            this.c2.TabIndex = 21;
            this.c2.Text = "C2";
            this.c2.UseVisualStyleBackColor = true;
            this.c2.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // c1
            // 
            this.c1.Location = new System.Drawing.Point(72, 443);
            this.c1.Name = "c1";
            this.c1.Size = new System.Drawing.Size(84, 63);
            this.c1.TabIndex = 20;
            this.c1.Text = "C1";
            this.c1.UseVisualStyleBackColor = true;
            this.c1.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // d6
            // 
            this.d6.Location = new System.Drawing.Point(522, 512);
            this.d6.Name = "d6";
            this.d6.Size = new System.Drawing.Size(84, 63);
            this.d6.TabIndex = 31;
            this.d6.Text = "D6";
            this.d6.UseVisualStyleBackColor = true;
            this.d6.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // d5
            // 
            this.d5.Location = new System.Drawing.Point(432, 512);
            this.d5.Name = "d5";
            this.d5.Size = new System.Drawing.Size(84, 63);
            this.d5.TabIndex = 30;
            this.d5.Text = "D5";
            this.d5.UseVisualStyleBackColor = true;
            this.d5.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // d4
            // 
            this.d4.Location = new System.Drawing.Point(342, 512);
            this.d4.Name = "d4";
            this.d4.Size = new System.Drawing.Size(84, 63);
            this.d4.TabIndex = 29;
            this.d4.Text = "D4";
            this.d4.UseVisualStyleBackColor = true;
            this.d4.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // d3
            // 
            this.d3.Location = new System.Drawing.Point(252, 512);
            this.d3.Name = "d3";
            this.d3.Size = new System.Drawing.Size(84, 63);
            this.d3.TabIndex = 28;
            this.d3.Text = "D3";
            this.d3.UseVisualStyleBackColor = true;
            this.d3.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // d2
            // 
            this.d2.Location = new System.Drawing.Point(162, 512);
            this.d2.Name = "d2";
            this.d2.Size = new System.Drawing.Size(84, 63);
            this.d2.TabIndex = 27;
            this.d2.Text = "D2";
            this.d2.UseVisualStyleBackColor = true;
            this.d2.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // d1
            // 
            this.d1.Location = new System.Drawing.Point(72, 512);
            this.d1.Name = "d1";
            this.d1.Size = new System.Drawing.Size(84, 63);
            this.d1.TabIndex = 26;
            this.d1.Text = "D1";
            this.d1.UseVisualStyleBackColor = true;
            this.d1.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // e6
            // 
            this.e6.Location = new System.Drawing.Point(522, 581);
            this.e6.Name = "e6";
            this.e6.Size = new System.Drawing.Size(84, 63);
            this.e6.TabIndex = 37;
            this.e6.Text = "E6";
            this.e6.UseVisualStyleBackColor = true;
            this.e6.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // e5
            // 
            this.e5.Location = new System.Drawing.Point(432, 581);
            this.e5.Name = "e5";
            this.e5.Size = new System.Drawing.Size(84, 63);
            this.e5.TabIndex = 36;
            this.e5.Text = "E5";
            this.e5.UseVisualStyleBackColor = true;
            this.e5.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // e4
            // 
            this.e4.Location = new System.Drawing.Point(342, 581);
            this.e4.Name = "e4";
            this.e4.Size = new System.Drawing.Size(84, 63);
            this.e4.TabIndex = 35;
            this.e4.Text = "E4";
            this.e4.UseVisualStyleBackColor = true;
            this.e4.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // e3
            // 
            this.e3.Location = new System.Drawing.Point(252, 581);
            this.e3.Name = "e3";
            this.e3.Size = new System.Drawing.Size(84, 63);
            this.e3.TabIndex = 34;
            this.e3.Text = "E3";
            this.e3.UseVisualStyleBackColor = true;
            this.e3.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // e2
            // 
            this.e2.Location = new System.Drawing.Point(162, 581);
            this.e2.Name = "e2";
            this.e2.Size = new System.Drawing.Size(84, 63);
            this.e2.TabIndex = 33;
            this.e2.Text = "E2";
            this.e2.UseVisualStyleBackColor = true;
            this.e2.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // e1
            // 
            this.e1.Location = new System.Drawing.Point(72, 581);
            this.e1.Name = "e1";
            this.e1.Size = new System.Drawing.Size(84, 63);
            this.e1.TabIndex = 32;
            this.e1.Text = "E1";
            this.e1.UseVisualStyleBackColor = true;
            this.e1.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // f6
            // 
            this.f6.Location = new System.Drawing.Point(522, 650);
            this.f6.Name = "f6";
            this.f6.Size = new System.Drawing.Size(84, 63);
            this.f6.TabIndex = 43;
            this.f6.Text = "F6";
            this.f6.UseVisualStyleBackColor = true;
            this.f6.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // f5
            // 
            this.f5.Location = new System.Drawing.Point(432, 650);
            this.f5.Name = "f5";
            this.f5.Size = new System.Drawing.Size(84, 63);
            this.f5.TabIndex = 42;
            this.f5.Text = "F5";
            this.f5.UseVisualStyleBackColor = true;
            this.f5.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // f4
            // 
            this.f4.Location = new System.Drawing.Point(342, 650);
            this.f4.Name = "f4";
            this.f4.Size = new System.Drawing.Size(84, 63);
            this.f4.TabIndex = 41;
            this.f4.Text = "F4";
            this.f4.UseVisualStyleBackColor = true;
            this.f4.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // f3
            // 
            this.f3.Location = new System.Drawing.Point(252, 650);
            this.f3.Name = "f3";
            this.f3.Size = new System.Drawing.Size(84, 63);
            this.f3.TabIndex = 40;
            this.f3.Text = "F3";
            this.f3.UseVisualStyleBackColor = true;
            this.f3.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // f2
            // 
            this.f2.Location = new System.Drawing.Point(162, 650);
            this.f2.Name = "f2";
            this.f2.Size = new System.Drawing.Size(84, 63);
            this.f2.TabIndex = 39;
            this.f2.Text = "F2";
            this.f2.UseVisualStyleBackColor = true;
            this.f2.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // f1
            // 
            this.f1.Location = new System.Drawing.Point(72, 650);
            this.f1.Name = "f1";
            this.f1.Size = new System.Drawing.Size(84, 63);
            this.f1.TabIndex = 38;
            this.f1.Text = "F1";
            this.f1.UseVisualStyleBackColor = true;
            this.f1.Click += new System.EventHandler(this.PlayerPositionButtonsEvent);
            // 
            // l12
            // 
            this.l12.Location = new System.Drawing.Point(1318, 650);
            this.l12.Name = "l12";
            this.l12.Size = new System.Drawing.Size(84, 63);
            this.l12.TabIndex = 79;
            this.l12.Text = "L12";
            this.l12.UseVisualStyleBackColor = true;
            // 
            // l11
            // 
            this.l11.Location = new System.Drawing.Point(1228, 650);
            this.l11.Name = "l11";
            this.l11.Size = new System.Drawing.Size(84, 63);
            this.l11.TabIndex = 78;
            this.l11.Text = "L11";
            this.l11.UseVisualStyleBackColor = true;
            // 
            // l10
            // 
            this.l10.Location = new System.Drawing.Point(1138, 650);
            this.l10.Name = "l10";
            this.l10.Size = new System.Drawing.Size(84, 63);
            this.l10.TabIndex = 77;
            this.l10.Text = "L10";
            this.l10.UseVisualStyleBackColor = true;
            // 
            // l9
            // 
            this.l9.Location = new System.Drawing.Point(1048, 650);
            this.l9.Name = "l9";
            this.l9.Size = new System.Drawing.Size(84, 63);
            this.l9.TabIndex = 76;
            this.l9.Text = "L9";
            this.l9.UseVisualStyleBackColor = true;
            // 
            // l8
            // 
            this.l8.Location = new System.Drawing.Point(958, 650);
            this.l8.Name = "l8";
            this.l8.Size = new System.Drawing.Size(84, 63);
            this.l8.TabIndex = 75;
            this.l8.Text = "L8";
            this.l8.UseVisualStyleBackColor = true;
            // 
            // l7
            // 
            this.l7.Location = new System.Drawing.Point(868, 650);
            this.l7.Name = "l7";
            this.l7.Size = new System.Drawing.Size(84, 63);
            this.l7.TabIndex = 74;
            this.l7.Text = "L7";
            this.l7.UseVisualStyleBackColor = true;
            // 
            // k12
            // 
            this.k12.Location = new System.Drawing.Point(1318, 581);
            this.k12.Name = "k12";
            this.k12.Size = new System.Drawing.Size(84, 63);
            this.k12.TabIndex = 73;
            this.k12.Text = "K12";
            this.k12.UseVisualStyleBackColor = true;
            // 
            // k11
            // 
            this.k11.Location = new System.Drawing.Point(1228, 581);
            this.k11.Name = "k11";
            this.k11.Size = new System.Drawing.Size(84, 63);
            this.k11.TabIndex = 72;
            this.k11.Text = "K11";
            this.k11.UseVisualStyleBackColor = true;
            // 
            // k10
            // 
            this.k10.Location = new System.Drawing.Point(1138, 581);
            this.k10.Name = "k10";
            this.k10.Size = new System.Drawing.Size(84, 63);
            this.k10.TabIndex = 71;
            this.k10.Text = "K10";
            this.k10.UseVisualStyleBackColor = true;
            // 
            // k9
            // 
            this.k9.Location = new System.Drawing.Point(1048, 581);
            this.k9.Name = "k9";
            this.k9.Size = new System.Drawing.Size(84, 63);
            this.k9.TabIndex = 70;
            this.k9.Text = "K9";
            this.k9.UseVisualStyleBackColor = true;
            // 
            // k8
            // 
            this.k8.Location = new System.Drawing.Point(958, 581);
            this.k8.Name = "k8";
            this.k8.Size = new System.Drawing.Size(84, 63);
            this.k8.TabIndex = 69;
            this.k8.Text = "K8";
            this.k8.UseVisualStyleBackColor = true;
            // 
            // k7
            // 
            this.k7.Location = new System.Drawing.Point(868, 581);
            this.k7.Name = "k7";
            this.k7.Size = new System.Drawing.Size(84, 63);
            this.k7.TabIndex = 68;
            this.k7.Text = "K7";
            this.k7.UseVisualStyleBackColor = true;
            // 
            // j12
            // 
            this.j12.Location = new System.Drawing.Point(1318, 512);
            this.j12.Name = "j12";
            this.j12.Size = new System.Drawing.Size(84, 63);
            this.j12.TabIndex = 67;
            this.j12.Text = "J12";
            this.j12.UseVisualStyleBackColor = true;
            // 
            // j11
            // 
            this.j11.Location = new System.Drawing.Point(1228, 512);
            this.j11.Name = "j11";
            this.j11.Size = new System.Drawing.Size(84, 63);
            this.j11.TabIndex = 66;
            this.j11.Text = "J11";
            this.j11.UseVisualStyleBackColor = true;
            // 
            // j10
            // 
            this.j10.Location = new System.Drawing.Point(1138, 512);
            this.j10.Name = "j10";
            this.j10.Size = new System.Drawing.Size(84, 63);
            this.j10.TabIndex = 65;
            this.j10.Text = "J10";
            this.j10.UseVisualStyleBackColor = true;
            // 
            // j9
            // 
            this.j9.Location = new System.Drawing.Point(1048, 512);
            this.j9.Name = "j9";
            this.j9.Size = new System.Drawing.Size(84, 63);
            this.j9.TabIndex = 64;
            this.j9.Text = "J9";
            this.j9.UseVisualStyleBackColor = true;
            // 
            // j8
            // 
            this.j8.Location = new System.Drawing.Point(958, 512);
            this.j8.Name = "j8";
            this.j8.Size = new System.Drawing.Size(84, 63);
            this.j8.TabIndex = 63;
            this.j8.Text = "J8";
            this.j8.UseVisualStyleBackColor = true;
            // 
            // j7
            // 
            this.j7.Location = new System.Drawing.Point(868, 512);
            this.j7.Name = "j7";
            this.j7.Size = new System.Drawing.Size(84, 63);
            this.j7.TabIndex = 62;
            this.j7.Text = "J7";
            this.j7.UseVisualStyleBackColor = true;
            // 
            // i12
            // 
            this.i12.Location = new System.Drawing.Point(1318, 443);
            this.i12.Name = "i12";
            this.i12.Size = new System.Drawing.Size(84, 63);
            this.i12.TabIndex = 61;
            this.i12.Text = "I12";
            this.i12.UseVisualStyleBackColor = true;
            // 
            // i11
            // 
            this.i11.Location = new System.Drawing.Point(1228, 443);
            this.i11.Name = "i11";
            this.i11.Size = new System.Drawing.Size(84, 63);
            this.i11.TabIndex = 60;
            this.i11.Text = "I11";
            this.i11.UseVisualStyleBackColor = true;
            // 
            // i10
            // 
            this.i10.Location = new System.Drawing.Point(1138, 443);
            this.i10.Name = "i10";
            this.i10.Size = new System.Drawing.Size(84, 63);
            this.i10.TabIndex = 59;
            this.i10.Text = "I10";
            this.i10.UseVisualStyleBackColor = true;
            // 
            // i9
            // 
            this.i9.Location = new System.Drawing.Point(1048, 443);
            this.i9.Name = "i9";
            this.i9.Size = new System.Drawing.Size(84, 63);
            this.i9.TabIndex = 58;
            this.i9.Text = "I9";
            this.i9.UseVisualStyleBackColor = true;
            // 
            // i8
            // 
            this.i8.Location = new System.Drawing.Point(958, 443);
            this.i8.Name = "i8";
            this.i8.Size = new System.Drawing.Size(84, 63);
            this.i8.TabIndex = 57;
            this.i8.Text = "I8";
            this.i8.UseVisualStyleBackColor = true;
            // 
            // i7
            // 
            this.i7.Location = new System.Drawing.Point(868, 443);
            this.i7.Name = "i7";
            this.i7.Size = new System.Drawing.Size(84, 63);
            this.i7.TabIndex = 56;
            this.i7.Text = "I7";
            this.i7.UseVisualStyleBackColor = true;
            // 
            // h12
            // 
            this.h12.Location = new System.Drawing.Point(1318, 374);
            this.h12.Name = "h12";
            this.h12.Size = new System.Drawing.Size(84, 63);
            this.h12.TabIndex = 55;
            this.h12.Text = "H12";
            this.h12.UseVisualStyleBackColor = true;
            // 
            // h11
            // 
            this.h11.Location = new System.Drawing.Point(1228, 374);
            this.h11.Name = "h11";
            this.h11.Size = new System.Drawing.Size(84, 63);
            this.h11.TabIndex = 54;
            this.h11.Text = "H11";
            this.h11.UseVisualStyleBackColor = true;
            // 
            // h10
            // 
            this.h10.Location = new System.Drawing.Point(1138, 374);
            this.h10.Name = "h10";
            this.h10.Size = new System.Drawing.Size(84, 63);
            this.h10.TabIndex = 53;
            this.h10.Text = "H10";
            this.h10.UseVisualStyleBackColor = true;
            // 
            // h9
            // 
            this.h9.Location = new System.Drawing.Point(1048, 374);
            this.h9.Name = "h9";
            this.h9.Size = new System.Drawing.Size(84, 63);
            this.h9.TabIndex = 52;
            this.h9.Text = "H9";
            this.h9.UseVisualStyleBackColor = true;
            // 
            // h8
            // 
            this.h8.Location = new System.Drawing.Point(958, 374);
            this.h8.Name = "h8";
            this.h8.Size = new System.Drawing.Size(84, 63);
            this.h8.TabIndex = 51;
            this.h8.Text = "H8";
            this.h8.UseVisualStyleBackColor = true;
            // 
            // h7
            // 
            this.h7.Location = new System.Drawing.Point(868, 374);
            this.h7.Name = "h7";
            this.h7.Size = new System.Drawing.Size(84, 63);
            this.h7.TabIndex = 50;
            this.h7.Text = "H7";
            this.h7.UseVisualStyleBackColor = true;
            // 
            // g12
            // 
            this.g12.Location = new System.Drawing.Point(1318, 305);
            this.g12.Name = "g12";
            this.g12.Size = new System.Drawing.Size(84, 63);
            this.g12.TabIndex = 49;
            this.g12.Text = "G12";
            this.g12.UseVisualStyleBackColor = true;
            // 
            // g11
            // 
            this.g11.Location = new System.Drawing.Point(1228, 305);
            this.g11.Name = "g11";
            this.g11.Size = new System.Drawing.Size(84, 63);
            this.g11.TabIndex = 48;
            this.g11.Text = "G11";
            this.g11.UseVisualStyleBackColor = true;
            // 
            // g10
            // 
            this.g10.Location = new System.Drawing.Point(1138, 305);
            this.g10.Name = "g10";
            this.g10.Size = new System.Drawing.Size(84, 63);
            this.g10.TabIndex = 47;
            this.g10.Text = "G10";
            this.g10.UseVisualStyleBackColor = true;
            // 
            // g9
            // 
            this.g9.Location = new System.Drawing.Point(1048, 305);
            this.g9.Name = "g9";
            this.g9.Size = new System.Drawing.Size(84, 63);
            this.g9.TabIndex = 46;
            this.g9.Text = "G9";
            this.g9.UseVisualStyleBackColor = true;
            // 
            // g8
            // 
            this.g8.Location = new System.Drawing.Point(958, 305);
            this.g8.Name = "g8";
            this.g8.Size = new System.Drawing.Size(84, 63);
            this.g8.TabIndex = 45;
            this.g8.Text = "G8";
            this.g8.UseVisualStyleBackColor = true;
            // 
            // g7
            // 
            this.g7.Location = new System.Drawing.Point(868, 305);
            this.g7.Name = "g7";
            this.g7.Size = new System.Drawing.Size(84, 63);
            this.g7.TabIndex = 44;
            this.g7.Text = "G7";
            this.g7.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(22, 320);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 37);
            this.label1.TabIndex = 80;
            this.label1.Text = "A";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(22, 384);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 37);
            this.label2.TabIndex = 81;
            this.label2.Text = "B";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(22, 453);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 37);
            this.label3.TabIndex = 82;
            this.label3.Text = "C";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(22, 522);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 37);
            this.label4.TabIndex = 83;
            this.label4.Text = "D";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(22, 591);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 37);
            this.label5.TabIndex = 84;
            this.label5.Text = "E";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(22, 660);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 37);
            this.label6.TabIndex = 85;
            this.label6.Text = "F";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.Location = new System.Drawing.Point(97, 250);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(33, 37);
            this.label7.TabIndex = 86;
            this.label7.Text = "1";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.Location = new System.Drawing.Point(185, 250);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 37);
            this.label8.TabIndex = 87;
            this.label8.Text = "2";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label9.Location = new System.Drawing.Point(270, 250);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 37);
            this.label9.TabIndex = 88;
            this.label9.Text = "3";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label10.Location = new System.Drawing.Point(365, 250);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 37);
            this.label10.TabIndex = 89;
            this.label10.Text = "4";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label11.Location = new System.Drawing.Point(450, 250);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 37);
            this.label11.TabIndex = 90;
            this.label11.Text = "5";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label12.Location = new System.Drawing.Point(547, 250);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(35, 37);
            this.label12.TabIndex = 91;
            this.label12.Text = "6";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label13.Location = new System.Drawing.Point(808, 660);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(35, 37);
            this.label13.TabIndex = 97;
            this.label13.Text = "L";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label14.Location = new System.Drawing.Point(808, 591);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(38, 37);
            this.label14.TabIndex = 96;
            this.label14.Text = "K";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label15.Location = new System.Drawing.Point(808, 522);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(33, 37);
            this.label15.TabIndex = 95;
            this.label15.Text = "J";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label16.Location = new System.Drawing.Point(808, 453);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(25, 37);
            this.label16.TabIndex = 94;
            this.label16.Text = "I";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label17.Location = new System.Drawing.Point(808, 384);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(40, 37);
            this.label17.TabIndex = 93;
            this.label17.Text = "H";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label18.Location = new System.Drawing.Point(808, 320);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(42, 37);
            this.label18.TabIndex = 92;
            this.label18.Text = "G";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label19.Location = new System.Drawing.Point(1344, 250);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(51, 37);
            this.label19.TabIndex = 103;
            this.label19.Text = "12";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label20.Location = new System.Drawing.Point(1247, 250);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(49, 37);
            this.label20.TabIndex = 102;
            this.label20.Text = "11";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label21.Location = new System.Drawing.Point(1162, 250);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(51, 37);
            this.label21.TabIndex = 101;
            this.label21.Text = "10";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label22.Location = new System.Drawing.Point(1067, 250);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(35, 37);
            this.label22.TabIndex = 100;
            this.label22.Text = "9";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label23.Location = new System.Drawing.Point(982, 250);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(35, 37);
            this.label23.TabIndex = 99;
            this.label23.Text = "8";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label24.Location = new System.Drawing.Point(894, 250);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(35, 37);
            this.label24.TabIndex = 98;
            this.label24.Text = "7";
            // 
            // EnemyPlayTimer
            // 
            this.EnemyPlayTimer.Interval = 1000;
            this.EnemyPlayTimer.Tick += new System.EventHandler(this.EnemyPlayTimerEvent);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label25.Location = new System.Drawing.Point(925, 41);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(276, 37);
            this.label25.TabIndex = 104;
            this.label25.Text = "Ruch przeciwnika:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label26.Location = new System.Drawing.Point(65, 156);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(295, 37);
            this.label26.TabIndex = 105;
            this.label26.Text = "Ilosc trafien gracza:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label27.Location = new System.Drawing.Point(936, 156);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(286, 37);
            this.label27.TabIndex = 106;
            this.label27.Text = "Ilosc trafien wroga:";
            // 
            // information
            // 
            this.information.AutoSize = true;
            this.information.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.information.Location = new System.Drawing.Point(549, 91);
            this.information.Name = "information";
            this.information.Size = new System.Drawing.Size(118, 37);
            this.information.TabIndex = 107;
            this.information.Text = "Default";
            this.information.Click += new System.EventHandler(this.information_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 25;
            this.listBox1.Location = new System.Drawing.Point(1515, 36);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(352, 454);
            this.listBox1.TabIndex = 108;
            // 
            // Add1
            // 
            this.Add1.Location = new System.Drawing.Point(1515, 496);
            this.Add1.Name = "Add1";
            this.Add1.Size = new System.Drawing.Size(352, 31);
            this.Add1.TabIndex = 109;
            // 
            // addname
            // 
            this.addname.Location = new System.Drawing.Point(1515, 533);
            this.addname.Name = "addname";
            this.addname.Size = new System.Drawing.Size(168, 85);
            this.addname.TabIndex = 110;
            this.addname.Text = "Dodaj imię";
            this.addname.UseVisualStyleBackColor = true;
            this.addname.Click += new System.EventHandler(this.addname_Click);
            // 
            // addsurname
            // 
            this.addsurname.Location = new System.Drawing.Point(1699, 533);
            this.addsurname.Name = "addsurname";
            this.addsurname.Size = new System.Drawing.Size(168, 85);
            this.addsurname.TabIndex = 111;
            this.addsurname.Text = "Dodaj nazwisko";
            this.addsurname.UseVisualStyleBackColor = true;
            this.addsurname.Click += new System.EventHandler(this.addsurname_Click);
            // 
            // trudny
            // 
            this.trudny.Location = new System.Drawing.Point(1065, 754);
            this.trudny.Name = "trudny";
            this.trudny.Size = new System.Drawing.Size(176, 47);
            this.trudny.TabIndex = 112;
            this.trudny.Text = "trudny";
            this.trudny.UseVisualStyleBackColor = true;
            this.trudny.Click += new System.EventHandler(this.trudny_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1919, 863);
            this.Controls.Add(this.trudny);
            this.Controls.Add(this.addsurname);
            this.Controls.Add(this.addname);
            this.Controls.Add(this.Add1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.information);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.l12);
            this.Controls.Add(this.l11);
            this.Controls.Add(this.l10);
            this.Controls.Add(this.l9);
            this.Controls.Add(this.l8);
            this.Controls.Add(this.l7);
            this.Controls.Add(this.k12);
            this.Controls.Add(this.k11);
            this.Controls.Add(this.k10);
            this.Controls.Add(this.k9);
            this.Controls.Add(this.k8);
            this.Controls.Add(this.k7);
            this.Controls.Add(this.j12);
            this.Controls.Add(this.j11);
            this.Controls.Add(this.j10);
            this.Controls.Add(this.j9);
            this.Controls.Add(this.j8);
            this.Controls.Add(this.j7);
            this.Controls.Add(this.i12);
            this.Controls.Add(this.i11);
            this.Controls.Add(this.i10);
            this.Controls.Add(this.i9);
            this.Controls.Add(this.i8);
            this.Controls.Add(this.i7);
            this.Controls.Add(this.h12);
            this.Controls.Add(this.h11);
            this.Controls.Add(this.h10);
            this.Controls.Add(this.h9);
            this.Controls.Add(this.h8);
            this.Controls.Add(this.h7);
            this.Controls.Add(this.g12);
            this.Controls.Add(this.g11);
            this.Controls.Add(this.g10);
            this.Controls.Add(this.g9);
            this.Controls.Add(this.g8);
            this.Controls.Add(this.g7);
            this.Controls.Add(this.f6);
            this.Controls.Add(this.f5);
            this.Controls.Add(this.f4);
            this.Controls.Add(this.f3);
            this.Controls.Add(this.f2);
            this.Controls.Add(this.f1);
            this.Controls.Add(this.e6);
            this.Controls.Add(this.e5);
            this.Controls.Add(this.e4);
            this.Controls.Add(this.e3);
            this.Controls.Add(this.e2);
            this.Controls.Add(this.e1);
            this.Controls.Add(this.d6);
            this.Controls.Add(this.d5);
            this.Controls.Add(this.d4);
            this.Controls.Add(this.d3);
            this.Controls.Add(this.d2);
            this.Controls.Add(this.d1);
            this.Controls.Add(this.c6);
            this.Controls.Add(this.c5);
            this.Controls.Add(this.c4);
            this.Controls.Add(this.c3);
            this.Controls.Add(this.c2);
            this.Controls.Add(this.c1);
            this.Controls.Add(this.b6);
            this.Controls.Add(this.b5);
            this.Controls.Add(this.b4);
            this.Controls.Add(this.b3);
            this.Controls.Add(this.b2);
            this.Controls.Add(this.b1);
            this.Controls.Add(this.a6);
            this.Controls.Add(this.a5);
            this.Controls.Add(this.a4);
            this.Controls.Add(this.a3);
            this.Controls.Add(this.a2);
            this.Controls.Add(this.a1);
            this.Controls.Add(this.btnAttack);
            this.Controls.Add(this.EnemyLocationListBox);
            this.Controls.Add(this.txtHelp);
            this.Controls.Add(this.enemyMove);
            this.Controls.Add(this.txtRounds);
            this.Controls.Add(this.txtEnemy);
            this.Controls.Add(this.txtPlayer);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txtPlayer;
        private System.Windows.Forms.Label txtEnemy;
        private System.Windows.Forms.Label txtRounds;
        private System.Windows.Forms.Label enemyMove;
        private System.Windows.Forms.Label txtHelp;
        private System.Windows.Forms.ComboBox EnemyLocationListBox;
        private System.Windows.Forms.Button btnAttack;
        private System.Windows.Forms.Button a1;
        private System.Windows.Forms.Button a2;
        private System.Windows.Forms.Button a3;
        private System.Windows.Forms.Button a4;
        private System.Windows.Forms.Button a5;
        private System.Windows.Forms.Button a6;
        private System.Windows.Forms.Button b6;
        private System.Windows.Forms.Button b5;
        private System.Windows.Forms.Button b4;
        private System.Windows.Forms.Button b3;
        private System.Windows.Forms.Button b2;
        private System.Windows.Forms.Button b1;
        private System.Windows.Forms.Button c6;
        private System.Windows.Forms.Button c5;
        private System.Windows.Forms.Button c4;
        private System.Windows.Forms.Button c3;
        private System.Windows.Forms.Button c2;
        private System.Windows.Forms.Button c1;
        private System.Windows.Forms.Button d6;
        private System.Windows.Forms.Button d5;
        private System.Windows.Forms.Button d4;
        private System.Windows.Forms.Button d3;
        private System.Windows.Forms.Button d2;
        private System.Windows.Forms.Button d1;
        private System.Windows.Forms.Button e6;
        private System.Windows.Forms.Button e5;
        private System.Windows.Forms.Button e4;
        private System.Windows.Forms.Button e3;
        private System.Windows.Forms.Button e2;
        private System.Windows.Forms.Button e1;
        private System.Windows.Forms.Button f6;
        private System.Windows.Forms.Button f5;
        private System.Windows.Forms.Button f4;
        private System.Windows.Forms.Button f3;
        private System.Windows.Forms.Button f2;
        private System.Windows.Forms.Button f1;
        private System.Windows.Forms.Button l12;
        private System.Windows.Forms.Button l11;
        private System.Windows.Forms.Button l10;
        private System.Windows.Forms.Button l9;
        private System.Windows.Forms.Button l8;
        private System.Windows.Forms.Button l7;
        private System.Windows.Forms.Button k12;
        private System.Windows.Forms.Button k11;
        private System.Windows.Forms.Button k10;
        private System.Windows.Forms.Button k9;
        private System.Windows.Forms.Button k8;
        private System.Windows.Forms.Button k7;
        private System.Windows.Forms.Button j12;
        private System.Windows.Forms.Button j11;
        private System.Windows.Forms.Button j10;
        private System.Windows.Forms.Button j9;
        private System.Windows.Forms.Button j8;
        private System.Windows.Forms.Button j7;
        private System.Windows.Forms.Button i12;
        private System.Windows.Forms.Button i11;
        private System.Windows.Forms.Button i10;
        private System.Windows.Forms.Button i9;
        private System.Windows.Forms.Button i8;
        private System.Windows.Forms.Button i7;
        private System.Windows.Forms.Button h12;
        private System.Windows.Forms.Button h11;
        private System.Windows.Forms.Button h10;
        private System.Windows.Forms.Button h9;
        private System.Windows.Forms.Button h8;
        private System.Windows.Forms.Button h7;
        private System.Windows.Forms.Button g12;
        private System.Windows.Forms.Button g11;
        private System.Windows.Forms.Button g10;
        private System.Windows.Forms.Button g9;
        private System.Windows.Forms.Button g8;
        private System.Windows.Forms.Button g7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Timer EnemyPlayTimer;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label information;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox Add1;
        private System.Windows.Forms.Button addname;
        private System.Windows.Forms.Button addsurname;
        private System.Windows.Forms.Button trudny;
    }
}

