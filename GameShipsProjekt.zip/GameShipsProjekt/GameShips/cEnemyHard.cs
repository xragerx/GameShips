﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace GameShips
{
    class cEnemyHard : cEnemy
    {
        private int Ships = 3;

        
        
        public Random rand = new Random();
        override public void LocationPicker(List<Button> aPositionButtons)
        {
            for (int i = 0; i < Ships; i++)
            {
                int index = rand.Next(aPositionButtons.Count);

                if (aPositionButtons[index].Enabled == true && (string)aPositionButtons[index].Tag == null)
                {
                    aPositionButtons[index].Tag = "enemyShip";

                    Debug.WriteLine("Pozycja wroga: " + aPositionButtons[index].Text);
                }
                else
                {
                    index = rand.Next(aPositionButtons.Count);
                    continue;
                }
                licznik++;
            }
        }
    }
}
